package com.example;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class SampleTest {

    @Test
    public void test() {
        assertTrue(true);
    }
}
