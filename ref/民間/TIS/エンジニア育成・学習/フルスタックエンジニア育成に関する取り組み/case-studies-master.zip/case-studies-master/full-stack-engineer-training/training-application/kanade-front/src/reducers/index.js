import { combineReducers } from 'redux';

const reducer = combineReducers({
});

export default reducer;
