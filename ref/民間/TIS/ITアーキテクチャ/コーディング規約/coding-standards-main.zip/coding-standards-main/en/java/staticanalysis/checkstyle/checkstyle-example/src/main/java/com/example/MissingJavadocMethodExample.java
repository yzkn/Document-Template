/*
 * Header example
 */
package com.example;

/**
 * Example of MissingJavadocMethod code.
 */
public class MissingJavadocMethodExample {

    public void noJavadocComment() {  // No javadoc comment (incorrect).

    }
}
