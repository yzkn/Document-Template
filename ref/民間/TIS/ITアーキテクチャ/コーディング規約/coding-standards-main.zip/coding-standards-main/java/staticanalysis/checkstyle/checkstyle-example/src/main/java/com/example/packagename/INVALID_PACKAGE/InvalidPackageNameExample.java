/*
 * Header example
 */
package com.example.packagename.INVALID_PACKAGE;    // パッケージ名が命名規約に違反しています（NG）。

/**
 * PackageNameのコード例です。
 */
public class InvalidPackageNameExample {
}
