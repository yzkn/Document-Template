/*
 * Header example
 */
package com.example;

/**
 * LocalVariableNameのコード例です。
 */
public class LocalVariableNameExample {

    /**
     * LocalVariableNameのコード例です。
     */
    public void example() {
        // 先頭が大文字のアルファベットになっています（NG）。
        String BadName = "NG";

        // アンダースコアを使用しています（NG）。
        String bad_name = "NG";

        // ルールに従った命名です（OK）。
        String goodName = "OK";
    }
}
