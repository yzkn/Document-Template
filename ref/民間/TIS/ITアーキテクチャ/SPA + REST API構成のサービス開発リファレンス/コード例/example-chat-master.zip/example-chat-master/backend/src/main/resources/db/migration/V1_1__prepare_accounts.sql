INSERT INTO account(account_id, mail_address, user_name) VALUES (0, 'chatbot@example.com', 'chatbot');
