/*
 * Header example
 */
package com.example;

/**
 * TodoCommentのコード例です。
 */
public class TodoCommentExample {
    /**
     * TodoCommentのコード例です。
     */
    public void example() {
        // TODOコメントが残っています（NG）。
        // TODO 処理が複雑なので後でリファクタリングが必要!
    }


}
