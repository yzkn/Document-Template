select
  /*%expand*/*
from
  user_profile
where
  mail_address = /* email */'test@example.com'