'use client';
import React from 'react';
import {Login} from '../../components/login/Login';

const LoginPage: React.FC = () => {
  return <Login />;
};

export default LoginPage;
