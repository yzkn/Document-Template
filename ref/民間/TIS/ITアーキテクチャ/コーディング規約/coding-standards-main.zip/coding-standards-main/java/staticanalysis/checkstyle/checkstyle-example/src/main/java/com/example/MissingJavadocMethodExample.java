/*
 * Header example
 */
package com.example;

/**
 * MissingJavadocMethodのコード例です。
 */
public class MissingJavadocMethodExample {

    public void noJavadocComment() {  // javadocコメントがありません（NG）。

    }
}
