/*
 * Header example
 */

/**
 * デフォルトパッケージを使用しています（NG）。
 */
public class PackageDeclarationExample {
}
