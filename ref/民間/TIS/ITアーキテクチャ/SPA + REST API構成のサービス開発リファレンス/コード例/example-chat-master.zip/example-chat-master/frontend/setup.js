module.exports = async () => {
  process.env.REACT_APP_BACKEND_BASE_URL = 'http://localhost:9080';
};