package com.example.api;

/**
 * Example of Unauthorized API check code.
 */
public class ClassC extends ClassB {

}
