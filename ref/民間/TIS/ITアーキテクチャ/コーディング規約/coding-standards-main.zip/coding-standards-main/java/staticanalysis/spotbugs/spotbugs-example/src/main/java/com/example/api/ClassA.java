package com.example.api;

/**
 * 使用不許可APIチェックのコード例です。
 */
public class ClassA {

    public void methodA() {
        System.out.println("ClassA#methodA");
    }

    public void methodB() {
        System.out.println("ClassA#methodB");
    }
}
