/*
 * Header example
 */
package com.example;

/**
 * Example of ParameterName code.
 */
public class ParameterNameExample {

    /**
     * Example of ParameterName code.
     *
     * @param BadName First character is an upper case letter (incorrect)
     * @param bad_name An underscore is used (incorrect)
     * @param goodName Name follows the rules (OK)
     */
    public void example(String BadName,
                        String bad_name,
                        String goodName) {
    }
}
