package com.example.infrastructure.persistence.entity;

public class ChannelIdSequence {

    private Long channelId;

    public Long getChannelId() {
        return channelId;
    }

    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }
}
