package com.example.domain.model.message;

public enum MessageType {
    TEXT, IMAGE
}
