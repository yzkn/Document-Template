'use client';
import React from 'react';
import {TodoBoard} from '../../components/board/TodoBoard';

const TodoBoardPage: React.FC = () => {
  return <TodoBoard />;
};

export default TodoBoardPage;
