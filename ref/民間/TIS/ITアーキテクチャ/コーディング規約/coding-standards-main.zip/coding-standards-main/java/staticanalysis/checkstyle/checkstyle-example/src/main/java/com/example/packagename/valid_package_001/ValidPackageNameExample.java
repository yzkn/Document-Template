/*
 * Header example
 */
package com.example.packagename.valid_package_001;  // 命名規則に則ったパッケージ名（OK）。

/**
 * PackageNameのコード例です。
 */
public class ValidPackageNameExample {
}
