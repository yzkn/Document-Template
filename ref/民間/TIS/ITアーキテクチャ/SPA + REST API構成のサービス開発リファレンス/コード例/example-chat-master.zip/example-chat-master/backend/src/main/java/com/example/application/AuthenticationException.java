package com.example.application;

public class AuthenticationException extends ChatApplicationException {

}
