package com.example.system.nablarch.handler;

public interface MessageConsumer {

    void consume(Message message);
}
