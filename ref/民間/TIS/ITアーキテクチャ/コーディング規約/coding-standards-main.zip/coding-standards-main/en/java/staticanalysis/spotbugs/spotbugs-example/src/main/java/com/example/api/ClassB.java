package com.example.api;

/**
 * Example of Unauthorized API check code.
 */
public class ClassB extends ClassA {

    @Override
    public void methodA() {
        System.out.println("ClassB#methodA");
    }
}
