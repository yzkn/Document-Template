package com.example.infrastructure.persistence.entity;

public class AccountIdSequence {

    private Long accountId;

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }
}
