package com.example.api;

/**
 * 使用不許可APIチェックのコード例です。
 */
public class ClassB extends ClassA {

    @Override
    public void methodA() {
        System.out.println("ClassB#methodA");
    }
}
