/*
 * Header example
 */
package com.example;

/**
 * Example of IllegalThrows code.
 */
public class IllegalThrowsExample {

    /**
     * Example of IllegalThrows code.
     *
     * @throws Exception Unpermitted exception (java.lang.Exception) (incorrect)
     */
    public void example() throws Exception {
    }
}
