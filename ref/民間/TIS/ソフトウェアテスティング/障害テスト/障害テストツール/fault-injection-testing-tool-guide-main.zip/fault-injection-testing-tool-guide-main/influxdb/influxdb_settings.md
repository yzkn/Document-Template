# InfluxDBの設定

## 自動セットアップの設定

[Automated Setup](https://github.com/docker-library/docs/blob/master/influxdb/README.md#automated-setup)のドキュメントを参考にして`compose.yaml`の`influxdb`で設定している`environment`配下の環境変数の値を適切なものに書き換えてください。
