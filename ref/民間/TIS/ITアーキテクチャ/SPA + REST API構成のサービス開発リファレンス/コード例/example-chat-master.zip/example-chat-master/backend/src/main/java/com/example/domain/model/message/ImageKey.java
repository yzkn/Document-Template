package com.example.domain.model.message;

public class ImageKey {

    private final String value;

    public ImageKey(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
