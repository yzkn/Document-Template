/*
 * Header example
 */

/**
 * Default package is used (incorrect).
 */
public class PackageDeclarationExample {
}
