package com.example;

/**
 * ES_COMPARING_STRINGS_WITH_EQ のコード例です。
 */
public class ComparingStringsWithEq {

    public boolean example() {
        String value1 = "a";
        String value2 = "b";
        return value1 == value2;
    }
}
