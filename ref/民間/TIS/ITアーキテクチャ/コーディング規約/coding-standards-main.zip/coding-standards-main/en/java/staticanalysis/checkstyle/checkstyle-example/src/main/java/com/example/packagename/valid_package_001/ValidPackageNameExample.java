/*
 * Header example
 */
package com.example.packagename.valid_package_001;  // Package name complies with naming conventions (OK).

/**
 * Example of PackageName code.
 */
public class ValidPackageNameExample {
}
