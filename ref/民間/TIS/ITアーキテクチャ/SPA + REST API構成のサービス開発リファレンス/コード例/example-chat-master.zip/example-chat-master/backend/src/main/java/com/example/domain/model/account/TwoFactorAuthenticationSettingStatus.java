package com.example.domain.model.account;

public enum TwoFactorAuthenticationSettingStatus {
    ENABLED, DISABLED
}
