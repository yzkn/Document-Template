package com.example.domain.model.message;

public class MessageHistoryKey {

    private final String value;

    public MessageHistoryKey(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
