function debug(message?: any, ...optionalParams: any[]): void {
}

const Logger = {
  debug,
};

export default Logger;

