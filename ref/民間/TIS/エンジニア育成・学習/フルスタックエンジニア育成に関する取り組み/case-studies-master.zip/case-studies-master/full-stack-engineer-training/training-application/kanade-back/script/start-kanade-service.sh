#!/bin/sh

sudo systemctl start kanade