package com.example.todo.domain;

public enum TodoStatus {
    INCOMPLETE,
    COMPLETED
}
