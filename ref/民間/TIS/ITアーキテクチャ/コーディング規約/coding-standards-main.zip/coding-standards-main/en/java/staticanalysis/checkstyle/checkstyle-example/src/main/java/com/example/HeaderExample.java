// Incorrect as the prescribed header is not used.
package com.example;

/**
 * Example of Header code.
 */
public class HeaderExample {
}
