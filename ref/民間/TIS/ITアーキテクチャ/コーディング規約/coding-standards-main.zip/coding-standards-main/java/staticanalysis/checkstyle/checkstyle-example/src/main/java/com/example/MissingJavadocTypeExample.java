/*
 * Header example
 */
package com.example;

// MissingJavadocTypeのコード例です
public class MissingJavadocTypeExample {  // javadocコメントがありません（NG）。
}

