export default {
  API_URL: 'https://api.kanade.keel-dev.net',
};
