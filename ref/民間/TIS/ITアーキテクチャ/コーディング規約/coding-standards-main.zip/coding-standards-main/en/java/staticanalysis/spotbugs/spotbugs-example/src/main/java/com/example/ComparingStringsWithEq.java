package com.example;

/**
 * Example of ES_COMPARING_STRINGS_WITH_EQ code.
 */
public class ComparingStringsWithEq {

    public boolean example() {
        String value1 = "a";
        String value2 = "b";
        return value1 == value2;
    }
}
