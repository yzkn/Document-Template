package com.example.application.service;

import com.example.domain.model.account.AccountId;

public interface LoginAccountIdSupplier {

    AccountId supply();
}
