#!/bin/sh

sudo systemctl stop kanade