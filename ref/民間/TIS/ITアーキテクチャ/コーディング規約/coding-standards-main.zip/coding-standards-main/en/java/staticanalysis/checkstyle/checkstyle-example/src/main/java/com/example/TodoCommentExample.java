/*
 * Header example
 */
package com.example;

/**
 * Example of TodoComment code.
 */
public class TodoCommentExample {
    /**
     * Example of TodoComment code.
     */
    public void example() {
        // A TO DO comment is left (incorrect).
        // TODO process is too complicated - refactor afterwards!
    }


}
