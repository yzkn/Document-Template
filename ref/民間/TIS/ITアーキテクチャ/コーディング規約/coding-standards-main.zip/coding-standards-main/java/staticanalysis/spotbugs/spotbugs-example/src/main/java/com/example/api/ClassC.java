package com.example.api;

/**
 * 使用不許可APIチェックのコード例です。
 */
public class ClassC extends ClassB {

}
