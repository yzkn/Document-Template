package com.example.application;

public class InvalidTokenException extends ChatApplicationException {

}
