/*
 * Header example
 */
package com.example;

/**
 * Example of LocalVariableName code.
 */
public class LocalVariableNameExample {

    /**
     * Example of LocalVariableName code.
     */
    public void example() {
        // First character is an upper case letter (incorrect).
        String BadName = "NG";

        // An underscore is used (incorrect).
        String bad_name = "NG";

        // Name follows the rules (OK).
        String goodName = "OK";
    }
}
