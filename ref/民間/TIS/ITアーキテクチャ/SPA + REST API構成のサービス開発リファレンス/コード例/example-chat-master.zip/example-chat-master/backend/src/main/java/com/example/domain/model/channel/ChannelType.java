package com.example.domain.model.channel;

public enum ChannelType {
    SYSTEM, CHANNEL
}
