package com.example.domain.event;

public interface Event {
}
