/*
 * Header example
 */
package com.example.packagename.INVALID_PACKAGE;    // Package name violates naming conventions (incorrect).

/**
 * Example of PackageName code.
 */
public class InvalidPackageNameExample {
}
