package com.example.authentication.application;

public enum AccountRegistrationResult {
    SUCCESS, NAME_CONFLICT
}
