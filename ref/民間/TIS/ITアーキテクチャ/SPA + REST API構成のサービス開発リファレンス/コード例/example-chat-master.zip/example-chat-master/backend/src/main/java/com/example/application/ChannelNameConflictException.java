package com.example.application;

public class ChannelNameConflictException extends ChatApplicationException {

}
