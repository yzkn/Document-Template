/*
 * Header example
 */
package com.example;

/**
 * UpperEllのコード例です。
 */
public class UpperEllExample {

    /**
     * UpperEllのコード例です。
     */
    public void example() {
        // 整数リテラルの接尾語に小文字の'l'を使用しています（NG）。
        long bad = 1l;

        // 整数リテラルの接尾語に大文字の'L'を使用しています（OK）。
        long good = 1L;
    }
}
