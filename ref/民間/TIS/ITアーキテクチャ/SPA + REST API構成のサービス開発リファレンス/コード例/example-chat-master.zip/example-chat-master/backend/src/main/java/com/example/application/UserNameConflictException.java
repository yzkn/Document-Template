package com.example.application;

public class UserNameConflictException extends ChatApplicationException {

}
