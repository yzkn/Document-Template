/*
 * Header example
 */
package com.example;

/**
 * IllegalThrowsのコード例です。
 */
public class IllegalThrowsExample {

    /**
     * IllegalThrowsのコード例です。
     * 
     * @throws Exception 許可されていない例外（java.lang.Exception）です（NG）
     */
    public void example() throws Exception {
    }
}
