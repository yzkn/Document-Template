package com.example.infrastructure.persistence.entity;

public class MessageIdSequence {

    private Long messageId;

    public Long getMessageId() {
        return messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }
}
