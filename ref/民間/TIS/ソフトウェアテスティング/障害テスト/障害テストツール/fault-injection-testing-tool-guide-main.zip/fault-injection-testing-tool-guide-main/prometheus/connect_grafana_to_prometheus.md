# GrafanaとPrometheusの連携

1. GrafanaのUIで"Configuration"->"Data Sources"に移動し、"Add data source"を選択
2. "Prometheus"を検索し選択
3. "URL"に`http://<ホスト名>:9090`を入力し"Save & Test"を押下
