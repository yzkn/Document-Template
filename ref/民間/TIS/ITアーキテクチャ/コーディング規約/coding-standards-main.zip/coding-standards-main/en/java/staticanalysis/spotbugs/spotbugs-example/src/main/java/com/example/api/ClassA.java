package com.example.api;

/**
 * Example of Unauthorized API check code.
 */
public class ClassA {

    public void methodA() {
        System.out.println("ClassA#methodA");
    }

    public void methodB() {
        System.out.println("ClassA#methodB");
    }
}
