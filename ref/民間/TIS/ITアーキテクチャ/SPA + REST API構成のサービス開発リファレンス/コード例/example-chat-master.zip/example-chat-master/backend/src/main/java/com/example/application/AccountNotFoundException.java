package com.example.application;

public class AccountNotFoundException extends ChatApplicationException {

}
