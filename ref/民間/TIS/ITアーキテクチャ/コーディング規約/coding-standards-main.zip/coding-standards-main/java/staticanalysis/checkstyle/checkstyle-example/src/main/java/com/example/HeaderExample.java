//規定のヘッダーが無いのでNG
package com.example;

/**
 * Headerのコード例です。
 */
public class HeaderExample {
}
