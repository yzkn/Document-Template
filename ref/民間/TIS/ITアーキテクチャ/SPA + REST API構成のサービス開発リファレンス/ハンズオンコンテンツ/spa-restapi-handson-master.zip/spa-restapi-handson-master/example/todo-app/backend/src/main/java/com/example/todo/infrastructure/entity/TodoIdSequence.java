package com.example.todo.infrastructure.entity;

public class TodoIdSequence {

    private Long todoId;

    public Long getTodoId() {
        return todoId;
    }

    public void setTodoId(Long todoId) {
        this.todoId = todoId;
    }
}
