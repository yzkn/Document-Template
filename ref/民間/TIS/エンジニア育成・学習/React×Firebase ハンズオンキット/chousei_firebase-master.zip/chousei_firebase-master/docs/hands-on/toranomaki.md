# 虎の巻


## Ant Design

https://ant.design/

- [ボタン](https://ant.design/components/button/)
- [タイトルや文字](https://ant.design/components/typography/)
- [入力フォーム](https://ant.design/components/form/)
- [テキストフィールド](https://ant.design/components/input/)
- [ラジオ](https://ant.design/components/radio/)

## React Router

https://reacttraining.com/react-router/web/guides/quick-start

- [基本的なサンプル](https://reacttraining.com/react-router/web/example/basic)
- [URLからパラメータ取得](https://reacttraining.com/react-router/web/example/url-params)
- [JSからAPIを使う](https://reacttraining.com/react-router/web/api/withRouter)


