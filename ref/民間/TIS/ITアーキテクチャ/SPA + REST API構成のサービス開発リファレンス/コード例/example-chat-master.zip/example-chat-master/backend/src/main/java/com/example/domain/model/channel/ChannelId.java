package com.example.domain.model.channel;

public class ChannelId {

    private final Long value;

    public ChannelId(Long value) {
        this.value = value;
    }

    public Long value() {
        return value;
    }
}
