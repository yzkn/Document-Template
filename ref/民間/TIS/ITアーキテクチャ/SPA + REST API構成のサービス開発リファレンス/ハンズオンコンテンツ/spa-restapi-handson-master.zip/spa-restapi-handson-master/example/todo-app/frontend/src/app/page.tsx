'use client';
import React from 'react';
import {Welcome} from '../components/welcome/Welcome';

export default function Home() {
  return <Welcome />;
}
