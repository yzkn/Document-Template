package com.example.todo.domain;

public class Tod {
}
