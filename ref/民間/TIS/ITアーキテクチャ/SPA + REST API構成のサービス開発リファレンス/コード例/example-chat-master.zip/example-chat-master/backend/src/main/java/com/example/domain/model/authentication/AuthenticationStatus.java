package com.example.domain.model.authentication;

public enum AuthenticationStatus {
    COMPLETE, WAITING_2FA
}
