'use client';
import React from 'react';

export default function Home() {
  return <h1>Hello, world</h1>;
}