/*
 * Header example
 */
package com.example;

// Example of MissingJavadocType code.
public class MissingJavadocTypeExample {  // No javadoc comment (incorrect).
}

